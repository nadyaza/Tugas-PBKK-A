<div class="container-fluid">
  <div class="alert alert-success">
    <p class="text-center">Selamat, pesanan Anda telah berhasil diproses!</p>
  </div>
</div>