<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hello World Page</title>
  <link rel="stylesheet" href="<?= base_url('/style.css'); ?>">
</head>

<body>
  <div class="container">
    <h1>Hello, World!</h1>
    <p>Saya sedang belajar PBKK dengan menggunakan framework CodeIgniter.</p>
  </div>
</body>

</html>